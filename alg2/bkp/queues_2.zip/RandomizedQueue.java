import java.util.Iterator;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomizedQueue<Item> implements Iterable<Item> 
{
   private Deque<Item> dq = null; 
   
   public RandomizedQueue()                 // construct an empty randomized queue
   {
	   dq = new Deque<Item>();
   }

   public boolean isEmpty()                 // is the randomized queue empty?
   {
	   return dq.isEmpty();
   }

   public int size()                        // return the number of items on the randomized queue
   {
	   return dq.size();
   }

   public void enqueue(Item item)           // add the item
   {
	   if (item == null) throw new java.lang.IllegalArgumentException();
	   
	   dq.addFirst(item);
   }

   /*
   private void dump_state()
   {
	   for(int i=0; i< valid.length; i++)
	   {
		   StdOut.println("value[" + i + "]: " + value[i] + ", valid[" + i + "]: " + valid[i]);		   
	   }
   }
   */
   
   private int GetRandomIndex()
   {
	   // find next valid item to dequeue
	   int size = dq.size();
	   
	   StdRandom.setSeed(System.currentTimeMillis());
	   int index = StdRandom.uniform(100) % size;
	   	   
	   return index;
   }
   
   public Item dequeue()                    // remove and return a random item
   {
	   if(isEmpty()) throw new java.util.NoSuchElementException();
	   
	   int index = GetRandomIndex();
	   Item temp;
	   for(int i = 0; i < index; ++i)
	   {
		   temp = dq.removeFirst();
		   dq.addLast(temp);
	   }	   
	   temp = dq.removeFirst(); 
	   
       return temp;
   }

   public Item sample()                     // return a random item (but do not remove it)
   {
	   if(isEmpty()) throw new java.util.NoSuchElementException();

	   int index = GetRandomIndex();
	   Item temp = null;
	   
	   Iterator<Item> itor = dq.iterator();
	   for(int i = 0; i < index; ++i) 
	   {
		   temp = itor.next();		   
	   }
       return temp;
   }

   public Iterator<Item> iterator()         // return an independent iterator over items in random order
   {
	   return new RandomizedQueueIterator(dq);
   }
   
   public class RandomizedQueueIterator implements Iterator<Item>
   {
	   Iterator<Item> itor;
	   public RandomizedQueueIterator(Deque<Item> dq)
	   {		   
		   itor = dq.iterator();
	   }
	   
	   public boolean hasNext() { return itor.hasNext(); }
	   
	   public Item next()
	   {
		   if(!hasNext()) throw new java.util.NoSuchElementException();
		   
		   int index = GetRandomIndex();
		   
		   Item temp = null;
		   
		   Iterator<Item> itor = dq.iterator();
		   for(int i = 0; i < index;)
		   {
			   temp = itor.next();
			   if(temp != null)
				   i++;			   
		   }
		   
		   return temp;
	   }
	   
	   public void remove() { throw new java.lang.UnsupportedOperationException(); } 
   }

   public static void main(String[] args)   // unit testing (optional)
   {
	   StdOut.println("RandomizedQueue...Done.");
   }
}